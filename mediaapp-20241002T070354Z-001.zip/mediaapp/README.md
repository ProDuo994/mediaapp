# mediaapp
Mediapp is a project I have been working on to test my JS and HTML skills. Mediapp is a chatting system where you can talk to freinds and groups.

To login or sign up visit https://produo994.github.io/mediaapp/frontend/login.html
